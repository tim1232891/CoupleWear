/* Couple Wear Studio 2.0: progressive enhancement. Works with Horizon's native product-form.
   No external library, no network requests and no modification to Shopify's cart API. */
(() => {
  const clean = (s) => String(s || '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim();
  function init(root) {
    if (root.dataset.cwInitialized === 'true') return;
    const names = root.querySelector('[data-cw-names-input]');
    const date = root.querySelector('[data-cw-date-input]');
    const font = root.querySelector('[data-cw-font-input]');
    const namesPreview = root.querySelector('[data-cw-names-preview]');
    const datePreview = root.querySelector('[data-cw-date-preview]');
    const counter = root.querySelector('[data-cw-counter]');
    const status = root.querySelector('[data-cw-status]');
    const form = root.closest('form');
    if (!names || !date || !font || !namesPreview || !datePreview || !form) return;
    root.dataset.cwInitialized = 'true';
    const render = () => {
      const name = clean(names.value);
      const dateText = clean(date.value);
      namesPreview.textContent = name || root.dataset.cwInitialNames || 'Eure Namen';
      datePreview.textContent = dateText || (name ? '' : root.dataset.cwInitialDate || '05.08.2022');
      root.dataset.cwFont = font.value;
      if (counter) counter.textContent = `${names.value.length} / ${names.maxLength}`;
      if (names.value.length) names.removeAttribute('aria-invalid');
    };
    [names, date].forEach((field) => field.addEventListener('input', render));
    font.addEventListener('change', render);
    // Trim unwanted surrounding spaces before Horizon constructs FormData(form).
    // Native required validation remains active; no custom AJAX submission.
    form.addEventListener('submit', (event) => {
      names.value = clean(names.value);
      date.value = clean(date.value);
      render();
      if (!names.value) {
        event.preventDefault();
        event.stopImmediatePropagation();
        names.setAttribute('aria-invalid', 'true');
        names.setCustomValidity('Bitte gib euren Wunschtext ein.');
        names.reportValidity();
        if (status) status.textContent = 'Bitte gib euren Wunschtext ein.';
      } else {
        names.setCustomValidity('');
        if (status) status.textContent = 'Die Personalisierung wird mit deiner Bestellung übermittelt.';
      }
    }, {capture:true});
    names.addEventListener('input', () => names.setCustomValidity(''));
    render();
  }
  function boot(root = document) { root.querySelectorAll('[data-cw-personalizer]').forEach(init); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => boot());
  else boot();
  // Shopify editor can replace sections without reloading the page.
  document.addEventListener('shopify:section:load', (event) => boot(event.target));
})();
